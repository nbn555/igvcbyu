#!/bin/bash

MY_PROMPT='$ '
MY_YESNO_PROMPT='(y/n)$ '

echo "This is a script to assist with installation of the FlyCapture SDK.";
echo "Would you like to continue and install all the FlyCapture SDK packages?";
echo -n "$MY_YESNO_PROMPT"
read confirm

if [ $confirm = "n" ] || [ $confirm = "N" ] || [ $confirm = "no" ] || [ $confirm = "No" ]
then
    exit 0
    break
fi

echo

echo "Installing FlyCapture packages...";

sudo dpkg -i libflycapture-2*
sudo dpkg -i libflycapturegui-2*
sudo dpkg -i libflycapture-c-2*
sudo dpkg -i libflycapturegui-c-2*
sudo dpkg -i flycap-2*
sudo dpkg -i flycapture-doc-2*

#notify server of a linux installation
wget -T 10 -q --spider http://www.ptgrey.com/support/softwarereg.asp?text=ProductName+Linux+FlyCapture2+2%2E1+Release+04+%0D%0AProductVersion+2%2E01%2E03%2E04%0D%0A

echo "Would you like to add a udev entry to allow access to 1394 and USB hardware?";
echo -n "$MY_YESNO_PROMPT"
read confirm

if [ $confirm = "n" ] || [ $confirm = "N" ] || [ $confirm = "no" ] || [ $confirm = "No" ]
then
	echo "Complete";
    exit 0
    break
fi

echo "Launching conf script";
sudo sh flycap2-conf

echo "Complete";

exit 0
