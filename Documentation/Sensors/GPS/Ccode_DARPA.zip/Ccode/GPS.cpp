

#include "stdafx.h"
#include <stdio.h>
#include "gps.h"

volatile struct gps data;//global struct storing gps information

#define BADSENTENCE 0
#define PARAMEXCEEDED 1

void setErrorDefaultsGPS();

char GPSBUFF[SIZE + 1];//Raw Data from GPS //I only need 52 bits, but I'll take 64

//Sempahore used to protect shared data for data 
//and index Semaphore used to protect shared data
HANDLE gpsMutex = CreateMutex( NULL, FALSE, NULL );  //mutex is not taken at initilization because second parameter false

DWORD dwThreadId;//id of thread 
HANDLE hSerialgps; //serial input
HANDLE hThread; //thread for gps


			//initilize serial port for reading data from GPS
			//return 0 if no errors otherwise returns -1
double convertToDouble(char* dbl, int len) {
	double retval = 0.0;
	for(int i = 0; i < len; i++) {
		retval += (int)dbl[i]*pow(2, dbl[i]);
	}
	printf("Your new double is: %f", retval);
	return retval;
}


int gpsInit()
{
	 /* initialize random generator */
	srand ( time(NULL) );//for GPS indoors
	//opens serial port 
	hSerialgps = CreateFile(GPSCOM,GENERIC_READ | GENERIC_WRITE,0,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
	if(hSerialgps==INVALID_HANDLE_VALUE)
	{
		if(GetLastError()==ERROR_FILE_NOT_FOUND){
			printf("Serial Port does not exisit\n");
			//serial port does not exist. Inform user.
			return -1;
		}
		printf("Serial Port unknown error\n");
		//some other error occurred. Inform user.
		return -1;
	}
	//paremeters
	
	DCB dcbSerialParams = {0};
	dcbSerialParams.DCBlength=sizeof(dcbSerialParams);
	if (!GetCommState(hSerialgps, &dcbSerialParams))
	{
		printf("error in getting state\n");
		//error getting state
		return -1;
	}
	dcbSerialParams.BaudRate=CBR_9600;
	dcbSerialParams.ByteSize=8;
	dcbSerialParams.StopBits=ONESTOPBIT;
	dcbSerialParams.Parity=NOPARITY;
	if(!SetCommState(hSerialgps, &dcbSerialParams)){
		printf("error in setting port state\n"); 
		//error setting serial port state
		return -1;
	}

	COMMTIMEOUTS timeouts={0};
	timeouts.ReadIntervalTimeout=50;
	timeouts.ReadTotalTimeoutConstant=50;
	timeouts.ReadTotalTimeoutMultiplier=10;
	timeouts.WriteTotalTimeoutConstant=50;
	timeouts.WriteTotalTimeoutMultiplier=10;
	if(!SetCommTimeouts(hSerialgps, &timeouts))
	{
		printf("error in setting timeouts\n");
	}

	printf("\r\nCom is set to 9600 by default, 'upping' to 57600");
	char* output = "COM THISPORT,57600,N,8,1,N,OFF,ON\r\n";
	DWORD dwBytesWrote;
	WriteFile(hSerialgps, output, strlen(output), &dwBytesWrote, NULL);
	sleep(30);	//wait for that command to sink in...
	printf("...Done.\r\nSetting my com to 57600 now.");
	dcbSerialParams.BaudRate=CBR_57600;
	if(!SetCommState(hSerialgps, &dcbSerialParams)){
		printf("error in setting port state\n"); 
		//error setting serial port state
		return -1;
	}
	//clear the buffer just in case
	DWORD dwBytesRead;
	ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL);



	WaitForSingleObject(gpsMutex,INFINITE);
	data.latdeg = -1.0;
	data.longdeg = -1.0;
	data.time = -1;
	ReleaseMutex(gpsMutex);

	//creates thread to read data
	hThread = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)gpsListen,NULL,0,&dwThreadId);//starts thread gpsListen
	if (hThread == NULL) {
		printf("Thread creation failed in gps\n");
        exit(EXIT_FAILURE);
    }
	return 0;
}

DWORD WINAPI  gpsListen(LPVOID lpParam )//this is the thread that reads from serial port 
{
	char PARSEBUFF[SIZE+1];
	char * BegString;
	char * BegTime;
	char * EndTime;
	char * BegLat;
	char * EndLat;
	char * BegLong;
	char * EndLong;
	char TEMP[15];
	char TEMPMIN[15];
	char TEMPDEG[15];

	char comma = ',';
	
	char firstbit[5];
	DWORD dwBytesRead = 0;
	//clear out the serial buffer and char buffers
	memset(GPSBUFF,'\0',SIZE);
	ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL);
	memcpy(firstbit, GPSBUFF, 4);
	firstbit[4] = '\0';

	// send a command to the GPS so it outputs in the correct format
	//printf("Sending GPS a log request...");
	//char* output = "LOG COM1 BESTUTM ONCE\r\n";
	//DWORD dwBytesWrote;
	//WriteFile(hSerialgps, output, 23, &dwBytesWrote, NULL);
	//sleep(1000);
	//printf("Done!\r\n");


					//// wait for the synchronization string 
					//while(strcmp(firstbit, "$BIN") != 0) {
					//	printf("Not Bin, got %s", firstbit);
					//	dwBytesRead = 0;
					//	memset(GPSBUFF,'\0',SIZE);
					//	ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL);
					//	memcpy(firstbit, GPSBUFF, 4);
					//	firstbit[4] = '\0';
					//}

	while(1)
	{	
		try {
			//refresh the structs
			printf("Updating UTM...");
			updateUTM();
			printf("Done!\r\n");
			printf("Updating GPS Position...");
			updatePos();
			printf("Done!\r\n");
			printf("Updating OMNISTAR...");
			updateOMNISTAR();
			printf("Done!\r\n");
			printf("Updating velocity...");
			updateVelocity();
			printf("Done!\r\n");
			printf("Updating time...");
			updateTime();
			printf("Done!\r\n");
			printf("Syncing GPS times...");
			syncTime();
			printf("Done!\r\n");

			//double lat, lon;
			////lat = (double)((GPSBUFF&&LATMASK)>>LATSHIFT
			//char latch[8];
			//char lonch[8];
			//memcpy(&lat, GPSBUFF + 20, 8);
			//memcpy(&lon, GPSBUFF + 28, 8);
			//printf("%lf\n", lat);
			//printf("%lf\n", lon);
			//data.latdeg = lat;
			//data.longdeg = lon*-1; //gotta get rid of that negative sign
			//data.time = -1;
		}
		catch (int e) {
			switch (e) {
				case BADSENTENCE :
					printf("Bad NMEA sentence in GPS\n");
					setErrorDefaultsGPS();
					break;
				case PARAMEXCEEDED :
					printf("Exceeded GPS parameters\n");
					setErrorDefaultsGPS();
					break;

			}
		}
	}
}
DWORD sendCommand(char* command) {
	DWORD dwBytesWrote;
	WriteFile(hSerialgps, command, strlen(command), &dwBytesWrote, NULL);
	WriteFile(hSerialgps, "\r\n", 2, &dwBytesWrote, NULL);
	return dwBytesWrote;
}
void clearBuffer() {
	//DWORD dwBytesRead;
	//memset(GPSBUFF,'\0',SIZE);
	//ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL); //clear out the RX buffer
}
void updateUTM() {
	DWORD dwBytesRead = 0;
	//clear out the serial buffer and char buffers
	printf("Clearing buffer");
	clearBuffer();	
	printf("...done!\r\n");
	//send the UTM command
	printf("Sending request...");
	sendCommand("LOG THISPORT BESTUTM ONCE");
	printf("done\r\n");

	clock_t timeout = clock() + 1000; //set a 1 second timeout
	int totalRead = 0;
	ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL);
	totalRead += dwBytesRead;
	printf("%d", totalRead);
	while(totalRead < BESTUTM_ASCII_MESSAGE_LENGTH) {	//BESTUTM command returns an ascii string 197 chars (bytes) long
		if(clock() > timeout) {
			printf("TIMEOUT, BREAKING!\r\n");
			break;
		}
		else {
			printf(".");
		}
		sleep(1);	//wait for data to return on the serial line
		ReadFile(hSerialgps, GPSBUFF, SIZE, &dwBytesRead, NULL); //read it off
		totalRead += dwBytesRead;	//increment total read
	}
	//parse UTM data here

	printf("Data (%d bytes):", totalRead);
	printf(GPSBUFF);
	return;
}
void updatePos() {
	printf("TODO\r\n");
}
void updateOMNISTAR() {
	printf("TODO\r\n");
}
void updateVelocity() {
	printf("TODO\r\n");
}
void updateTime() {
	printf("TODO\r\n");
}
void syncTime() {
	printf("TODO\r\n");
}

gps getGPSData()
{
	struct gps temp;
	
	WaitForSingleObject(gpsMutex,INFINITE);
	temp.latdeg = data.latdeg;
	temp.longdeg = data.longdeg;
	temp.time = data.time;
	ReleaseMutex(gpsMutex);

	return temp;
}

void setErrorDefaultsGPS() {
	WaitForSingleObject(gpsMutex,INFINITE);
	data.latdeg = -1.0;
	data.longdeg = rand();
	data.time = -1;
	ReleaseMutex(gpsMutex);
}

void EndGPS()
{
	CloseHandle (hThread);
	char* output = "FRESET COMMAND\r\n";
	DWORD dwBytesWrote;
	WriteFile(hSerialgps, output, strlen(output), &dwBytesWrote, NULL);
	printf("\r\nReset GPS, closing com port\r\n");
	sleep(30);
	CloseHandle (hSerialgps);
}

int main(){
	printf("initializing GPS\n");
	gpsInit();
	printf("Done, press q to quit.\n");
	while(1){
		if(getchar() == 'q') {
			//end it... sent the reset command and stop the thread.
			EndGPS();
			break;
		}
	}
}
