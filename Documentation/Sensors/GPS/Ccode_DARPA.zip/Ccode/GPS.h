#ifndef GPS_H
#define GPS_H

#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <math.h>
#define SIZE 256
#define GPSCOM "COM2"
#define LATMASK	0xFF
#define LATSHIFT 0xFF


#define BESTUTM_ASCII_MESSAGE_LENGTH 196 //char length for BESTUTM log message

struct gps 
{
    int time;		//time in the format hhmmss
    double latdeg;     //latitude degrees
    double longdeg;     //longitude degrees  
	char type;
};

int gpsInit();
gps getGPSData();  // call to get data from GPS 
void EndGPS();  //terminates thread for GPS
DWORD WINAPI gpsListen(LPVOID lpParam ); //this is thread that runs in background getting data from serial port
//API functions
void updateUTM();
void updatePos();
void updateOMNISTAR();
void updateVelocity();
void updateTime();
void syncTime();
DWORD sendCommand(char* command);
void clearBuffer();

void sleep(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}

#endif