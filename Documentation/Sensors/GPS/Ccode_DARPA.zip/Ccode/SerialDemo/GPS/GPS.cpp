// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"
#include "GPS.h"

#using <mscorlib.dll>

using namespace System;

GPS::GPS() {
	Init();
}
GPS::~GPS() {
	Stop();
}

int GPS::Init() {
	gpsMutex = CreateMutex( NULL, FALSE, NULL );  //mutex is not taken at initilization because second parameter false

	LONG    lLastError = ERROR_SUCCESS;
    lLastError = serial.Open(_T("COM2"),0,0,false);
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Unable to open COM-port"));

    // Setup the serial port (9600,N81) using hardware handshaking
    lLastError = serial.Setup(CSerial::EBaud9600,CSerial::EData8,CSerial::EParNone,CSerial::EStop1);
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Unable to set COM-port setting"));

	//send the command to move the GPS up to 57600 baud
    lLastError = serial.Write("COM THISPORT,57600,N,8,1,N,OFF,ON\r\n");
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Unable to set com port to 57600!"));

	//initialize the structs
	WaitForSingleObject(gpsMutex,INFINITE);
/*
	data.latdeg = -1.0;
	data.longdeg = -1.0;
	data.time = -1;
*/
	ReleaseMutex(gpsMutex);

	//start the thread
	hThread = CreateThread(NULL,0,(unsigned long (__stdcall *)(void *))this->runThread,NULL,0,&dwThreadId);//starts thread gpsListen
	if (hThread == NULL) {
		printf("[FATAL ERROR] - Thread creation failed in gps!\n");
        return 0;
    }

	return 1;
}
int GPS::Stop() {  //terminates thread for GPS
	//send the FRESET command
	sendCommand("COM THISPORT,57600,N,8,1,N,OFF,ON\r\n", "Unable to set com port to 57600!");
    lLastError = serial.Write("COM THISPORT,57600,N,8,1,N,OFF,ON\r\n");
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Unable to set com port to 57600!"));	
	//close the port
	serial.Close();
	return 1;
}
int GPS::gpsListen(){ //this is thread that runs in background getting data from serial port
	clearBuffer();
	while(1) {
		try {
			//refresh the structs
			printf("Updating UTM...");
			updateUTM();
			printf("Done!\r\n");
			printf("Updating GPS Position...");
			updatePos();
			printf("Done!\r\n");
			printf("Updating OMNISTAR...");
			updateOMNISTAR();
			printf("Done!\r\n");
			printf("Updating velocity...");
			updateVelocity();
			printf("Done!\r\n");
			printf("Updating time...");
			updateTime();
			printf("Done!\r\n");
			printf("Syncing GPS times...");
			syncTime();
			printf("Done!\r\n");
		}
		catch (int e) {
			printf("Error, return code: %d", e);
		}
	}
}
//functions called by the tread
int GPS::updateUTM(){
	DWORD dwBytesRead = 0;
	//clear out the serial buffer and char buffers
	clearBuffer();	
	//send the UTM command
	sendCommand("LOG THISPORT BESTUTM ONCE", "Could not send BESTUTM command");

	clock_t timeout = clock() + 1000; //set a 1 second timeout
	int totalRead = 0;

	lLastError = serial.Read(GPSBUFF,BUFFER_SIZE,&dwBytesRead);
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Error reading UTM result!"));

	totalRead += dwBytesRead;
	while(totalRead != BESTUTM_ASCII_MESSAGE_LENGTH) {	//BESTUTM command returns an ascii string 197 chars (bytes) long
		if(clock() > timeout) {
			printf("--TIMEOUT--\r\n");
			break;
		}
		sleep(1);	//wait for data to return on the serial line
		lLastError = serial.Read(GPSBUFF+totalRead,BUFFER_SIZE,&dwBytesRead);
		if (lLastError != ERROR_SUCCESS)
			return ::ShowError(serial.GetLastError(), _T("Error reading UTM result!"));
		totalRead += dwBytesRead;	//increment total read
	}
	//parse UTM data here

	printf("Data (%d bytes):", totalRead);
	printf(GPSBUFF);
	return 1;
}
int GPS::updatePos() {
	printf("TODO\r\n");
	return 1;
}
int GPS::updateOMNISTAR() {
	printf("TODO\r\n");
	return 1;
}
int GPS::updateVelocity() {
	printf("TODO\r\n");
	return 1;
}
int GPS::updateTime() {
	printf("TODO\r\n");
	return 1;
}
int GPS::syncTime() {
	printf("TODO\r\n");
	return 1;
}

//general utility functions
int GPS::sendCommand(char* command, char* errormsg) {
    lLastError = serial.Write(command);
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T(errormsg));
	return 1;
}
int GPS::clearBuffer() {
	DWORD dwBytesRead;
	printf("Clearing the buffer...\r\n");
	//memset(GPSBUFF,'\0',BUFFER_SIZE);
	lLastError = serial.Read(GPSBUFF,BUFFER_SIZE,&dwBytesRead);
	if (lLastError != ERROR_SUCCESS)
		return ::ShowError(serial.GetLastError(), _T("Error reading from serial!"));
	return 1;
}
//this is the method the thread is created with, it calls the actual gpsListen fuction
int GPS::runThread (void* pThis)
{
	return ((GPS*)(pThis))->gpsListen();
}	
int _tmain()
{
    // TODO: Please replace the sample code below with your own.
    Console::WriteLine(S"Starting GPS...");
	GPS* myGPS = new GPS(); //GPS calls "Init()" already;
	printf("Done, press q to quit.\n");
	while(1){
		if(getchar() == 'q') {
			//end it... sent the reset command and stop the thread.
			delete myGPS;
			break;
		}
	}	
	return 0;
}