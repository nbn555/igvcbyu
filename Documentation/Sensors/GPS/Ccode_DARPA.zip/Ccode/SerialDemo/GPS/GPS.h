#ifndef GPS_H
#define GPS_H
#include <tchar.h>
#include <windows.h>
#include <time.h>
#include "Serial.h"
#define GPSCOM "COM2"
#define BUFFER_SIZE 256

#define BESTUTM_ASCII_MESSAGE_LENGTH 198 //char length for BESTUTM log message


class GPS {
public:
	GPS();	//calls Init();
	~GPS(); //calls Stop();
	int Init();
	int Stop();  //terminates thread for GPS
private:
	//GLOBAL VARIABLES
    CSerial serial;
	LONG    lLastError;
	char GPSBUFF[BUFFER_SIZE + 1];//Raw Data from GPS 
	//Sempahore used to protect shared data for data 
	//and index Semaphore used to protect shared data
	HANDLE gpsMutex;
	DWORD dwThreadId;//id of thread 
	HANDLE hThread; //thread for gps
	struct BestPosLog
	{
		double 	lat; 		//latitude
		double 	lon;		//longitude
		double 	hgt;		//height above mean sea level
		float 	lat_dev;	//latitude deviation
		float	lon_dev;	//longitude deviation
		float	hgt_dev;	//height deviation
		char	stn_id[4];		//base station id
		unsigned char	obs;		//number of satellites tracked
		float	diff_age;	//Differential age in seconds
		float	sol_age;	//Solution age in seconds
		
	};
	struct BestUtmLog
	{
		unsigned long	zone_num;	//Longitudinal zone number
		unsigned long	zone_letter;	//Latitudinal zone letter
		double 	northing;	//northing
		double	easting;	//easting
		double	hgt;		//height above mean sea level
		float	nor_dev	;	//northing deviation
		float	east_dev;	//easting deviation
		float	hgt_dev;	//height deviation
		char	stn_id[4];		//base station id
		unsigned char	obs;		//number of satellites tracked	
		float	diff_age;	//Differential age in seconds
		float	sol_age;	//Solution age in seconds
		
	};
	//PRIVATE FUNCTIONS
//static method
	static int runThread(void* pThis);	//this is the function the thread is created with
	int gpsListen(); //this is thread that runs in background getting data from serial port
	//API functions
	int updateUTM();
	int updatePos();
	int updateOMNISTAR();
	int updateVelocity();
	int updateTime();
	int syncTime();
	int sendCommand(char* command, char* errormsg);
	int clearBuffer();
};
void sleep(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
int ShowError (LONG lError, LPCTSTR lptszMessage)
{
	// Generate a message text
	TCHAR tszMessage[256];
	wsprintf(tszMessage,_T("%s\n(error code %d)"), lptszMessage, lError);

	// Display message-box and return with an error-code
	::MessageBox(0,tszMessage,_T("Hello world"), MB_ICONSTOP|MB_OK);
	return 0;
}
#endif