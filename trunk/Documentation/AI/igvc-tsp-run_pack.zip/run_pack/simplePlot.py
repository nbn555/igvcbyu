import numpy as np
import matplotlib.pyplot as plt
import sys

filename = sys.argv[1]
#f = open('t1.tsp', 'r')
f = open(filename, 'r')
points = np.zeros((10,2))
size = 0
xmin = 0
ymin = 0
xc, yc = f.readline().split()
xo = xc
yo = yc
ptsx = []
ptsy = []
ptsx.append(int(xc))
ptsy.append(int(yc))
xmax = int(xc);
ymax = int(yc);

for line in f:
	xn, yn = line.split()
	if(int(xn) > xmax):
		xmax = int(xn)
	if(int(yn) > ymax):
		ymax = int(yn)
	ptsx.append(int(xn))
	ptsy.append(int(yn))
ptsx.append(int(xo))
ptsy.append(int(yo))

plt.plot(ptsx, ptsy,'o-')
plt.axis([xmin, xmax+int(round(xmax*0.3)), ymin, ymax+int(round(ymax*0.3))])
plt.show()
