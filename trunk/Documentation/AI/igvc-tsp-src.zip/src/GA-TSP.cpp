#include <iostream>
#include <stdlib.h>
#include "TSPSolver.h"
using namespace lkinhou;

int main(int argi, char ** argv) {

	if(argi!=6){
			cout << "please input params in order: " << endl;
			cout << "1. filename" << endl;
			cout << "2. # of unchange, then stop" << endl;
			cout << "3. # of population" << endl;
			cout << "4. # of parents" << endl;
			cout << "5. # of swap cities" << endl;
			return 0;
		}
	//int numPopulation = 10;
	//int numStop = 50000;
	int numPopulation = atoi(argv[3]);
	int numStop = atoi(argv[2]);
	//int numParents = 6;
	int numParents = atoi(argv[4]);
	//int numSwapCitiesInMutation = 4;
	int numSwapCitiesInMutation = atoi(argv[5]);

	TSPSolver solver(numPopulation, numStop, numParents, numSwapCitiesInMutation, argv[1]);

	//solver.testIt();
	solver.solveIt();
	return 0;
}
