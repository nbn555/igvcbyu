
Readme.txt for PocketMax PC and PocketMax

PocketMax PC is a Win32 executable (i.e. it is not packaged as an installer).
To use the file, copy it to a directory of your chosing (desktop, c:\, c:\Program Files\Hemisphere\, etc.).
To run the program, just open it by double clicking its icon on the desktop, or its icon or filename in a directory listing.

PocketMax (for Power PC 2003) is an ARM executable (i.e. it is not packaged as an installer).
To use the file, copy it to a directory of your chosing (\, \Program Files, etc.) using Microsoft ActiveSync (a free download from Microsoft).
To run the program, just open it by single clicking its icon or filename in a directory listing.

In some cases, previous software versions may create configuration files that are incompatibile with the newer software.
